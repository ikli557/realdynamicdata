"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Smartphone } from "lucide-react"
import Link from "next/link"
import { useParams } from "next/navigation"

const networkData = {
  mtn: {
    name: "MTN",
    color: "bg-yellow-500",
    description: "Nigeria's largest network with nationwide coverage",
    plans: [
      { id: "mtn_500mb", size: "500MB", price: 324, duration: "30 days", popular: false },
      { id: "mtn_1gb", size: "1GB", price: 486, duration: "30 days", popular: true },
      { id: "mtn_2gb", size: "2GB", price: 810, duration: "30 days", popular: true },
      { id: "mtn_3gb", size: "3GB", price: 1215, duration: "30 days", popular: false },
      { id: "mtn_5gb", size: "5GB", price: 1620, duration: "30 days", popular: true },
      { id: "mtn_10gb", size: "10GB", price: 3240, duration: "30 days", popular: false },
      { id: "mtn_15gb", size: "15GB", price: 4860, duration: "30 days", popular: false },
      { id: "mtn_20gb", size: "20GB", price: 6480, duration: "30 days", popular: false },
    ],
  },
  airtel: {
    name: "Airtel",
    color: "bg-red-500",
    description: "Fast and reliable data plans at competitive prices",
    plans: [
      { id: "airtel_500mb", size: "500MB", price: 324, duration: "30 days", popular: false },
      { id: "airtel_1gb", size: "1GB", price: 486, duration: "30 days", popular: true },
      { id: "airtel_2gb", size: "2GB", price: 810, duration: "30 days", popular: true },
      { id: "airtel_3gb", size: "3GB", price: 1215, duration: "30 days", popular: false },
      { id: "airtel_5gb", size: "5GB", price: 1620, duration: "30 days", popular: true },
      { id: "airtel_10gb", size: "10GB", price: 3240, duration: "30 days", popular: false },
      { id: "airtel_15gb", size: "15GB", price: 4860, duration: "30 days", popular: false },
      { id: "airtel_20gb", size: "20GB", price: 6480, duration: "30 days", popular: false },
    ],
  },
  glo: {
    name: "Glo",
    color: "bg-green-500",
    description: "Affordable data bundles with good coverage",
    plans: [
      { id: "glo_500mb", size: "500MB", price: 324, duration: "30 days", popular: false },
      { id: "glo_1gb", size: "1GB", price: 486, duration: "30 days", popular: true },
      { id: "glo_2gb", size: "2GB", price: 810, duration: "30 days", popular: true },
      { id: "glo_3gb", size: "3GB", price: 1215, duration: "30 days", popular: false },
      { id: "glo_5gb", size: "5GB", price: 1620, duration: "30 days", popular: true },
      { id: "glo_10gb", size: "10GB", price: 3240, duration: "30 days", popular: false },
      { id: "glo_15gb", size: "15GB", price: 4860, duration: "30 days", popular: false },
      { id: "glo_20gb", size: "20GB", price: 6480, duration: "30 days", popular: false },
    ],
  },
  "9mobile": {
    name: "9mobile",
    color: "bg-teal-600",
    description: "Quality network services with flexible plans",
    plans: [
      { id: "9mobile_500mb", size: "500MB", price: 324, duration: "30 days", popular: false },
      { id: "9mobile_1gb", size: "1GB", price: 486, duration: "30 days", popular: true },
      { id: "9mobile_2gb", size: "2GB", price: 810, duration: "30 days", popular: true },
      { id: "9mobile_3gb", size: "3GB", price: 1215, duration: "30 days", popular: false },
      { id: "9mobile_5gb", size: "5GB", price: 1620, duration: "30 days", popular: true },
      { id: "9mobile_10gb", size: "10GB", price: 3240, duration: "30 days", popular: false },
      { id: "9mobile_15gb", size: "15GB", price: 4860, duration: "30 days", popular: false },
      { id: "9mobile_20gb", size: "20GB", price: 6480, duration: "30 days", popular: false },
    ],
  },
}

export default function NetworkPlans() {
  const params = useParams()
  const networkId = params.network as string
  const network = networkData[networkId]

  if (!network) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="text-center py-8">
            <h2 className="text-2xl font-bold mb-4">Network Not Found</h2>
            <p className="text-gray-600 mb-4">The requested network could not be found.</p>
            <Link href="/">
              <Button>Go Back Home</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="ghost" size="sm">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
            </Link>
            <div className="flex items-center space-x-2">
              <Smartphone className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">RealDynamic DataPlans</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Network Header */}
        <div className="text-center mb-12">
          <div className={`w-24 h-24 ${network.color} rounded-full mx-auto mb-6 flex items-center justify-center`}>
            <span className="text-white font-bold text-3xl">{network.name[0]}</span>
          </div>
          <h2 className="text-4xl font-bold text-gray-900 mb-4">{network.name} Data Plans</h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">{network.description}</p>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {network.plans.map((plan) => (
            <Card
              key={plan.id}
              className={`relative hover:shadow-lg transition-shadow ${plan.popular ? "ring-2 ring-blue-500" : ""}`}
            >
              {plan.popular && (
                <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-blue-500">Popular</Badge>
              )}
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">{plan.size}</CardTitle>
                <CardDescription>{plan.duration}</CardDescription>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <div className="text-3xl font-bold text-green-600">₦{plan.price}</div>
                <div className="text-sm text-gray-500">Valid for {plan.duration}</div>
                <Link href="/dashboard">
                  <Button className="w-full">Buy Now</Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Payment Info */}
        <div className="mt-16">
          <Card className="max-w-2xl mx-auto border-2 border-blue-200">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl text-blue-600">🔒 Secure Payment Process</CardTitle>
              <CardDescription>Payment verification required before data delivery</CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="bg-blue-50 p-6 rounded-lg">
                <h3 className="font-bold text-lg mb-2">Bank Account Details</h3>
                <p className="text-2xl font-bold text-blue-600">9153897727</p>
                <p className="text-lg">Opay</p>
                <p className="text-lg font-semibold">Adebayo Samuel Temitope</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">🛡️ Security Features:</h4>
                <ul className="text-sm text-green-700 text-left space-y-1">
                  <li>✅ Payment verification before delivery</li>
                  <li>✅ SSL encryption & fraud protection</li>
                  <li>✅ 24/7 transaction monitoring</li>
                  <li>✅ Secure receipt verification</li>
                </ul>
              </div>
              <Badge variant="secondary" className="text-sm">
                🔐 Bank-grade security • Anti-fraud system • Instant verification
              </Badge>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
