import { type NextRequest, NextResponse } from "next/server"
import crypto from "crypto"
import { rateLimit } from "@/lib/rate-limit"
import { validateInput } from "@/lib/security"

// Enhanced security headers
const securityHeaders = {
  "X-Content-Type-Options": "nosniff",
  "X-Frame-Options": "DENY",
  "X-XSS-Protection": "1; mode=block",
  "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
  "Content-Security-Policy": "default-src 'self'",
}

// Network API configurations with enhanced security
const NETWORK_APIS = {
  mtn: {
    endpoint: process.env.MTN_API_ENDPOINT || "https://api.mtn.ng/v1/data",
    apiKey: process.env.MTN_API_KEY,
    secret: process.env.MTN_API_SECRET,
    headers: {
      Authorization: `Bearer ${process.env.MTN_API_KEY}`,
      "Content-Type": "application/json",
      "X-API-Version": "1.0",
    },
  },
  airtel: {
    endpoint: process.env.AIRTEL_API_ENDPOINT || "https://api.airtel.ng/v1/data",
    apiKey: process.env.AIRTEL_API_KEY,
    secret: process.env.AIRTEL_API_SECRET,
    headers: {
      Authorization: `Bearer ${process.env.AIRTEL_API_KEY}`,
      "Content-Type": "application/json",
      "X-API-Version": "1.0",
    },
  },
  glo: {
    endpoint: process.env.GLO_API_ENDPOINT || "https://api.glo.com/v1/data",
    apiKey: process.env.GLO_API_KEY,
    secret: process.env.GLO_API_SECRET,
    headers: {
      Authorization: `Bearer ${process.env.GLO_API_KEY}`,
      "Content-Type": "application/json",
      "X-API-Version": "1.0",
    },
  },
  "9mobile": {
    endpoint: process.env.NINMOBILE_API_ENDPOINT || "https://api.9mobile.com.ng/v1/data",
    apiKey: process.env.NINMOBILE_API_KEY,
    secret: process.env.NINMOBILE_API_SECRET,
    headers: {
      Authorization: `Bearer ${process.env.NINMOBILE_API_KEY}`,
      "Content-Type": "application/json",
      "X-API-Version": "1.0",
    },
  },
}

// Updated plan costs with 26% markup (wholesale prices)
const PLAN_COSTS = {
  mtn_1gb: 300, // Your cost: ₦300, Selling: ₦378 (26% markup)
  mtn_2gb: 500, // Your cost: ₦500, Selling: ₦630 (26% markup)
  mtn_5gb: 1000, // Your cost: ₦1000, Selling: ₦1260 (26% markup)
  mtn_10gb: 2000, // Your cost: ₦2000, Selling: ₦2520 (26% markup)
  mtn_20gb: 4000, // Your cost: ₦4000, Selling: ₦5040 (26% markup)

  airtel_1gb: 300,
  airtel_2gb: 500,
  airtel_5gb: 1000,
  airtel_10gb: 2000,
  airtel_20gb: 4000,

  glo_1gb: 300,
  glo_2gb: 500,
  glo_5gb: 1000,
  glo_10gb: 2000,
  glo_20gb: 4000,

  "9mobile_1gb": 300,
  "9mobile_2gb": 500,
  "9mobile_5gb": 1000,
  "9mobile_10gb": 2000,
  "9mobile_20gb": 4000,
}

// Selling prices with 62% markup
const SELLING_PRICES = {
  mtn_1gb: 486,
  mtn_2gb: 810,
  mtn_5gb: 1620,
  mtn_10gb: 3240,
  mtn_20gb: 6480,

  airtel_1gb: 486,
  airtel_2gb: 810,
  airtel_5gb: 1620,
  airtel_10gb: 3240,
  airtel_20gb: 6480,

  glo_1gb: 486,
  glo_2gb: 810,
  glo_5gb: 1620,
  glo_10gb: 3240,
  glo_20gb: 6480,

  "9mobile_1gb": 486,
  "9mobile_2gb": 810,
  "9mobile_5gb": 1620,
  "9mobile_10gb": 3240,
  "9mobile_20gb": 6480,
}

// Enhanced security function to generate secure transaction ID
function generateSecureTransactionId(): string {
  const timestamp = Date.now()
  const randomBytes = crypto.randomBytes(8).toString("hex")
  const hash = crypto.createHash("sha256").update(`${timestamp}${randomBytes}`).digest("hex").substring(0, 8)
  return `RDD_${timestamp}_${hash}`
}

// Enhanced logging with security considerations
function secureLog(level: "info" | "error" | "warn", message: string, data?: any) {
  const logData = {
    timestamp: new Date().toISOString(),
    level,
    message,
    // Remove sensitive data from logs
    data: data
      ? JSON.parse(
          JSON.stringify(data, (key, value) => {
            if (["apiKey", "secret", "password", "token"].includes(key.toLowerCase())) {
              return "[REDACTED]"
            }
            return value
          }),
        )
      : undefined,
  }
  console.log(JSON.stringify(logData))
}

async function verifyPaymentReceipt(
  receiptData: string,
  expectedAmount: number,
  transactionId: string,
): Promise<boolean> {
  try {
    // In production, implement actual payment verification
    // This could involve OCR, bank API integration, or manual verification queue

    // For demo purposes, simulate verification process
    await new Promise((resolve) => setTimeout(resolve, 3000))

    // Simulate 95% success rate for demo
    const isVerified = Math.random() > 0.05

    secureLog("info", "Payment verification completed", {
      transactionId,
      expectedAmount,
      verified: isVerified,
    })

    return isVerified
  } catch (error) {
    secureLog("error", "Payment verification failed", { transactionId, error: error.message })
    return false
  }
}

async function sendDataToNetwork(network: string, planId: string, phoneNumber: string, transactionId: string) {
  const networkConfig = NETWORK_APIS[network]

  if (!networkConfig || !networkConfig.apiKey) {
    throw new Error(`Network ${network} not configured or API key missing`)
  }

  try {
    // Create secure request signature
    const timestamp = Date.now().toString()
    const nonce = crypto.randomBytes(16).toString("hex")
    const payload = JSON.stringify({ planId, phoneNumber, timestamp, nonce })

    // In production, create HMAC signature for request authentication
    const signature = crypto
      .createHmac("sha256", networkConfig.secret || "fallback_secret")
      .update(payload)
      .digest("hex")

    // Enhanced security headers for network API calls
    const secureHeaders = {
      ...networkConfig.headers,
      "X-Timestamp": timestamp,
      "X-Nonce": nonce,
      "X-Signature": signature,
      "X-Transaction-ID": transactionId,
    }

    // Simulate network API call with enhanced security
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const mockResponse = {
      success: true,
      transactionId: transactionId,
      networkTransactionId: `${network.toUpperCase()}_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      message: "Data sent successfully",
      network: network,
      planId: planId,
      phoneNumber: phoneNumber,
      timestamp: new Date().toISOString(),
      signature: crypto.createHash("sha256").update(`${transactionId}${phoneNumber}`).digest("hex").substring(0, 16),
    }

    secureLog("info", "Data sent to network successfully", {
      transactionId,
      network,
      phoneNumber: phoneNumber.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2"), // Mask phone number in logs
    })

    return mockResponse
  } catch (error) {
    secureLog("error", "Network API call failed", { transactionId, network, error: error.message })
    throw new Error(`Failed to send data via ${network}: ${error.message}`)
  }
}

async function deductFromAccount(amount: number, transactionId: string) {
  try {
    // Enhanced security for account deduction
    const accountNumber = process.env.BUSINESS_ACCOUNT_NUMBER || "9153897727"
    const bankCode = process.env.BUSINESS_BANK_CODE || "OPAY"

    // Create secure transaction record
    const deductionRecord = {
      transactionId,
      accountNumber: accountNumber.replace(/(\d{3})\d{4}(\d{3})/, "$1****$2"), // Mask account number
      amount,
      timestamp: new Date().toISOString(),
      status: "completed",
    }

    // Simulate secure bank API call
    await new Promise((resolve) => setTimeout(resolve, 1500))

    secureLog("info", "Account deduction completed", deductionRecord)

    return {
      success: true,
      deductedAmount: amount,
      remainingBalance: 50000, // Mock balance
      transactionId: transactionId,
      bankReference: `BANK_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
    }
  } catch (error) {
    secureLog("error", "Account deduction failed", { transactionId, error: error.message })
    throw new Error(`Failed to deduct from account: ${error.message}`)
  }
}

export async function POST(request: NextRequest) {
  try {
    // Apply rate limiting (max 5 requests per minute per IP)
    const rateLimitResult = await rateLimit(request)
    if (!rateLimitResult.success) {
      return NextResponse.json(
        { success: false, message: "Too many requests. Please try again later." },
        { status: 429, headers: securityHeaders },
      )
    }

    // Get client IP for security logging
    const clientIP = request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "unknown"

    const body = await request.json()
    const { network, planId, phoneNumber, paymentReceipt } = body

    // Enhanced input validation
    const validationResult = validateInput({
      network,
      planId,
      phoneNumber,
      paymentReceipt,
    })

    if (!validationResult.isValid) {
      secureLog("warn", "Invalid input detected", {
        clientIP,
        errors: validationResult.errors,
      })
      return NextResponse.json(
        { success: false, message: "Invalid input data" },
        { status: 400, headers: securityHeaders },
      )
    }

    // Validate phone number with enhanced regex
    const phoneRegex = /^(\+234|234|0)?[789][01]\d{8}$/
    if (!phoneRegex.test(phoneNumber)) {
      return NextResponse.json(
        { success: false, message: "Invalid Nigerian phone number format" },
        { status: 400, headers: securityHeaders },
      )
    }

    // Get plan costs and selling prices
    const planCost = PLAN_COSTS[planId]
    const sellingPrice = SELLING_PRICES[planId]

    if (!planCost || !sellingPrice) {
      return NextResponse.json(
        { success: false, message: "Invalid plan selected" },
        { status: 400, headers: securityHeaders },
      )
    }

    // Generate secure transaction ID
    const transactionId = generateSecureTransactionId()

    secureLog("info", "Purchase request initiated", {
      transactionId,
      network,
      planId,
      clientIP,
      phoneNumber: phoneNumber.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2"),
    })

    // Step 1: Verify payment receipt (PAYMENT FIRST)
    const paymentVerified = await verifyPaymentReceipt(paymentReceipt, sellingPrice, transactionId)

    if (!paymentVerified) {
      secureLog("warn", "Payment verification failed", { transactionId, clientIP })
      return NextResponse.json(
        {
          success: false,
          message: "Payment verification failed. Please ensure you sent the correct amount and upload a clear receipt.",
        },
        { status: 400, headers: securityHeaders },
      )
    }

    // Step 2: Send data to network (ONLY AFTER PAYMENT VERIFICATION)
    const networkResponse = await sendDataToNetwork(network, planId, phoneNumber, transactionId)

    if (!networkResponse.success) {
      secureLog("error", "Network delivery failed after payment verification", { transactionId })
      // In production, you might want to refund or retry
      throw new Error("Data delivery failed. Please contact support with your transaction ID.")
    }

    // Step 3: Deduct wholesale cost from your account
    const deductionResponse = await deductFromAccount(planCost, transactionId)

    if (!deductionResponse.success) {
      secureLog("error", "Account deduction failed but data was delivered", { transactionId })
      // Continue as data was already delivered
    }

    // Step 4: Create comprehensive transaction log
    const transactionLog = {
      transactionId,
      networkTransactionId: networkResponse.networkTransactionId,
      network,
      planId,
      phoneNumber: phoneNumber.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2"),
      customerPrice: sellingPrice,
      wholesaleCost: planCost,
      profit: sellingPrice - planCost,
      profitMargin: "62%",
      paymentVerified: true,
      dataDelivered: true,
      accountDebited: deductionResponse.success,
      clientIP,
      timestamp: new Date().toISOString(),
      status: "completed",
      securityHash: crypto
        .createHash("sha256")
        .update(`${transactionId}${phoneNumber}${sellingPrice}`)
        .digest("hex")
        .substring(0, 16),
    }

    secureLog("info", "Transaction completed successfully", transactionLog)

    return NextResponse.json(
      {
        success: true,
        message: "Payment verified and data delivered successfully!",
        transactionId: networkResponse.transactionId,
        networkTransactionId: networkResponse.networkTransactionId,
        network: network.toUpperCase(),
        phoneNumber: phoneNumber,
        amount: sellingPrice,
        profit: sellingPrice - planCost,
        timestamp: new Date().toISOString(),
      },
      { headers: securityHeaders },
    )
  } catch (error) {
    const errorId = crypto.randomBytes(8).toString("hex")
    secureLog("error", "Purchase processing error", {
      errorId,
      error: error.message,
      stack: error.stack,
    })

    return NextResponse.json(
      {
        success: false,
        message: "An error occurred while processing your purchase. Please contact support.",
        errorId: errorId,
      },
      { status: 500, headers: securityHeaders },
    )
  }
}

// Health check endpoint with security
export async function GET(request: NextRequest) {
  return NextResponse.json(
    {
      status: "healthy",
      timestamp: new Date().toISOString(),
      version: "2.0.0-secure",
    },
    { headers: securityHeaders },
  )
}
