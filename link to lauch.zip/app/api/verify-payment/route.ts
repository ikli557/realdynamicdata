import { type NextRequest, NextResponse } from "next/server"

// Paystack verification
async function verifyPaystackPayment(reference: string) {
  const response = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
    headers: {
      Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`,
    },
  })

  const data = await response.json()
  return data.status && data.data.status === "success"
}

// Flutterwave verification
async function verifyFlutterwavePayment(transactionId: string) {
  const response = await fetch(`https://api.flutterwave.com/v3/transactions/${transactionId}/verify`, {
    headers: {
      Authorization: `Bearer ${process.env.FLUTTERWAVE_SECRET_KEY}`,
    },
  })

  const data = await response.json()
  return data.status === "success" && data.data.status === "successful"
}

export async function POST(request: NextRequest) {
  try {
    const { reference, provider } = await request.json()

    let isVerified = false

    if (provider === "paystack") {
      isVerified = await verifyPaystackPayment(reference)
    } else if (provider === "flutterwave") {
      isVerified = await verifyFlutterwavePayment(reference)
    }

    return NextResponse.json({
      success: isVerified,
      message: isVerified ? "Payment verified" : "Payment verification failed",
    })
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        message: "Verification error",
      },
      { status: 500 },
    )
  }
}
