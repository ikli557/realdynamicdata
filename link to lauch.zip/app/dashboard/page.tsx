"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Smartphone, CreditCard, CheckCircle, AlertCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

const networks = {
  mtn: {
    name: "MTN",
    color: "bg-yellow-500",
    plans: [
      { id: "mtn_1gb", size: "1GB", price: 486, duration: "30 days" },
      { id: "mtn_2gb", size: "2GB", price: 810, duration: "30 days" },
      { id: "mtn_5gb", size: "5GB", price: 1620, duration: "30 days" },
      { id: "mtn_10gb", size: "10GB", price: 3240, duration: "30 days" },
      { id: "mtn_20gb", size: "20GB", price: 6480, duration: "30 days" },
    ],
  },
  airtel: {
    name: "Airtel",
    color: "bg-red-500",
    plans: [
      { id: "airtel_1gb", size: "1GB", price: 486, duration: "30 days" },
      { id: "airtel_2gb", size: "2GB", price: 810, duration: "30 days" },
      { id: "airtel_5gb", size: "5GB", price: 1620, duration: "30 days" },
      { id: "airtel_10gb", size: "10GB", price: 3240, duration: "30 days" },
      { id: "airtel_20gb", size: "20GB", price: 6480, duration: "30 days" },
    ],
  },
  glo: {
    name: "Glo",
    color: "bg-green-500",
    plans: [
      { id: "glo_1gb", size: "1GB", price: 486, duration: "30 days" },
      { id: "glo_2gb", size: "2GB", price: 810, duration: "30 days" },
      { id: "glo_5gb", size: "5GB", price: 1620, duration: "30 days" },
      { id: "glo_10gb", size: "10GB", price: 3240, duration: "30 days" },
      { id: "glo_20gb", size: "20GB", price: 6480, duration: "30 days" },
    ],
  },
  "9mobile": {
    name: "9mobile",
    color: "bg-teal-600",
    plans: [
      { id: "9mobile_1gb", size: "1GB", price: 486, duration: "30 days" },
      { id: "9mobile_2gb", size: "2GB", price: 810, duration: "30 days" },
      { id: "9mobile_5gb", size: "5GB", price: 1620, duration: "30 days" },
      { id: "9mobile_10gb", size: "10GB", price: 3240, duration: "30 days" },
      { id: "9mobile_20gb", size: "20GB", price: 6480, duration: "30 days" },
    ],
  },
}

export default function Dashboard() {
  const [selectedNetwork, setSelectedNetwork] = useState("")
  const [selectedPlan, setSelectedPlan] = useState("")
  const [phoneNumber, setPhoneNumber] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const { toast } = useToast()
  const [paymentReceipt, setPaymentReceipt] = useState<File | null>(null)

  const handlePurchase = async () => {
    if (!selectedNetwork || !selectedPlan || !phoneNumber) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    try {
      const response = await fetch("/api/purchase-data", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          network: selectedNetwork,
          planId: selectedPlan,
          phoneNumber: phoneNumber,
        }),
      })

      const result = await response.json()

      if (result.success) {
        toast({
          title: "Purchase Successful!",
          description: `Data has been sent to ${phoneNumber}. Transaction ID: ${result.transactionId}`,
        })

        // Reset form
        setSelectedNetwork("")
        setSelectedPlan("")
        setPhoneNumber("")
      } else {
        throw new Error(result.message)
      }
    } catch (error) {
      toast({
        title: "Purchase Failed",
        description: error.message || "An error occurred while processing your purchase",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const selectedNetworkData = selectedNetwork ? networks[selectedNetwork] : null
  const selectedPlanData = selectedNetworkData?.plans.find((plan) => plan.id === selectedPlan)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Smartphone className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">RealDynamic DataPlans</h1>
          </div>
          <Badge variant="secondary">Dashboard</Badge>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Purchase Form */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CreditCard className="h-5 w-5" />
                  <span>Purchase Data</span>
                </CardTitle>
                <CardDescription>
                  Select your network, plan, and enter your phone number to get instant data
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="network">Select Network</Label>
                  <Select value={selectedNetwork} onValueChange={setSelectedNetwork}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose your network" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(networks).map(([key, network]) => (
                        <SelectItem key={key} value={key}>
                          <div className="flex items-center space-x-2">
                            <div className={`w-3 h-3 ${network.color} rounded-full`}></div>
                            <span>{network.name}</span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {selectedNetworkData && (
                  <div className="space-y-2">
                    <Label htmlFor="plan">Select Data Plan</Label>
                    <Select value={selectedPlan} onValueChange={setSelectedPlan}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose your data plan" />
                      </SelectTrigger>
                      <SelectContent>
                        {selectedNetworkData.plans.map((plan) => (
                          <SelectItem key={plan.id} value={plan.id}>
                            <div className="flex justify-between items-center w-full">
                              <span>{plan.size}</span>
                              <span className="font-bold text-green-600">₦{plan.price}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="08012345678"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="receipt">Payment Receipt (Required)</Label>
                  <Input
                    id="receipt"
                    type="file"
                    accept="image/*,.pdf"
                    onChange={(e) => setPaymentReceipt(e.target.files?.[0] || null)}
                    required
                  />
                  <p className="text-xs text-gray-500">Upload screenshot or receipt of your payment</p>
                </div>

                <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                  <h4 className="font-semibold text-yellow-800 mb-2">⚠️ Important Payment Instructions:</h4>
                  <ol className="text-sm text-yellow-700 space-y-1">
                    <li>
                      1. Send exact amount to: <strong>9153897727 (Opay - Adebayo Samuel Temitope)</strong>
                    </li>
                    <li>2. Take screenshot of successful payment</li>
                    <li>3. Upload receipt above and click "Submit for Verification"</li>
                    <li>4. Data will be delivered within 5 minutes after verification</li>
                  </ol>
                </div>

                <Button
                  onClick={handlePurchase}
                  className="w-full"
                  size="lg"
                  disabled={isProcessing || !selectedNetwork || !selectedPlan || !phoneNumber || !paymentReceipt}
                >
                  {isProcessing ? "Verifying Payment..." : "Submit for Verification"}
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary & Payment Info */}
          <div className="space-y-6">
            {/* Order Summary */}
            {selectedPlanData && (
              <Card>
                <CardHeader>
                  <CardTitle>Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex justify-between">
                    <span>Network:</span>
                    <span className="font-semibold">{selectedNetworkData.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Data Plan:</span>
                    <span className="font-semibold">{selectedPlanData.size}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Duration:</span>
                    <span className="font-semibold">{selectedPlanData.duration}</span>
                  </div>
                  <div className="border-t pt-4">
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total:</span>
                      <span className="text-green-600">₦{selectedPlanData.price}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Payment Information */}
            <Card className="border-2 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-600">Payment Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-blue-50 p-4 rounded-lg text-center">
                  <h3 className="font-bold mb-2">Bank Account Details</h3>
                  <p className="text-xl font-bold text-blue-600">9153897727</p>
                  <p>Opay</p>
                  <p className="font-semibold">Adebayo Samuel Temitope</p>
                </div>
                <div className="flex items-start space-x-2 text-sm text-gray-600">
                  <AlertCircle className="h-4 w-4 mt-0.5 text-blue-500" />
                  <p>Data will be delivered automatically within 5 minutes after payment confirmation.</p>
                </div>
              </CardContent>
            </Card>

            {/* Features */}
            <Card>
              <CardHeader>
                <CardTitle>Why Choose Us?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Instant delivery</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">24/7 customer support</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Secure transactions</span>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  <span className="text-sm">Best prices guaranteed</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
