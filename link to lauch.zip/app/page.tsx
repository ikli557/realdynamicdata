import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Shield, Clock, Smartphone } from "lucide-react"
import Link from "next/link"

const networks = [
  {
    id: "mtn",
    name: "MTN",
    color: "bg-yellow-500",
    description: "Nigeria's largest network with nationwide coverage",
    plans: [
      { size: "1GB", price: 486, originalPrice: 300, duration: "30 days" },
      { size: "2GB", price: 810, originalPrice: 500, duration: "30 days" },
      { size: "5GB", price: 1620, originalPrice: 1000, duration: "30 days" },
      { size: "10GB", price: 3240, originalPrice: 2000, duration: "30 days" },
    ],
  },
  {
    id: "airtel",
    name: "Airtel",
    color: "bg-red-500",
    description: "Fast and reliable data plans at competitive prices",
    plans: [
      { size: "1GB", price: 486, originalPrice: 300, duration: "30 days" },
      { size: "2GB", price: 810, originalPrice: 500, duration: "30 days" },
      { size: "5GB", price: 1620, originalPrice: 1000, duration: "30 days" },
      { size: "10GB", price: 3240, originalPrice: 2000, duration: "30 days" },
    ],
  },
  {
    id: "glo",
    name: "Glo",
    color: "bg-green-500",
    description: "Affordable data bundles with good coverage",
    plans: [
      { size: "1GB", price: 486, originalPrice: 300, duration: "30 days" },
      { size: "2GB", price: 810, originalPrice: 500, duration: "30 days" },
      { size: "5GB", price: 1620, originalPrice: 1000, duration: "30 days" },
      { size: "10GB", price: 3240, originalPrice: 2000, duration: "30 days" },
    ],
  },
  {
    id: "9mobile",
    name: "9mobile",
    color: "bg-teal-600",
    description: "Quality network services with flexible plans",
    plans: [
      { size: "1GB", price: 486, originalPrice: 300, duration: "30 days" },
      { size: "2GB", price: 810, originalPrice: 500, duration: "30 days" },
      { size: "5GB", price: 1620, originalPrice: 1000, duration: "30 days" },
      { size: "10GB", price: 3240, originalPrice: 2000, duration: "30 days" },
    ],
  },
]

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="border-b bg-white/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Smartphone className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">RealDynamic DataPlans</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Link href="/auth/signin">
              <Button variant="ghost">Sign In</Button>
            </Link>
            <Link href="/auth/signup">
              <Button>Sign Up</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">Data Plans for All Networks</h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Get the best data plans for MTN, Airtel, Glo, and 9mobile. Fast, reliable, and affordable internet for
            everyone.
          </p>

          <div className="flex justify-center items-center space-x-8 mb-12">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <span className="text-gray-700">Instant Delivery</span>
            </div>
            <div className="flex items-center space-x-2">
              <Shield className="h-5 w-5 text-blue-500" />
              <span className="text-gray-700">Trusted Service</span>
            </div>
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-purple-500" />
              <span className="text-gray-700">24/7 Support</span>
            </div>
          </div>

          <div className="flex justify-center space-x-4">
            <Link href="/dashboard">
              <Button size="lg" className="px-8">
                Get Started Now
              </Button>
            </Link>
            <Link href="/auth/signin">
              <Button variant="outline" size="lg" className="px-8">
                Sign in to Buy Data
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Payment Info */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <Card className="max-w-2xl mx-auto border-2 border-blue-200">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl text-blue-600">Secure Payment Process</CardTitle>
              <CardDescription>
                Payment must be completed before data delivery - 100% secure transactions
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className="bg-blue-50 p-6 rounded-lg">
                <h3 className="font-bold text-lg mb-2">Bank Account Details</h3>
                <p className="text-2xl font-bold text-blue-600">9153897727</p>
                <p className="text-lg">Opay</p>
                <p className="text-lg font-semibold">Adebayo Samuel Temitope</p>
              </div>
              <div className="bg-green-50 p-4 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">🔒 Secure Process:</h4>
                <ol className="text-sm text-green-700 text-left space-y-1">
                  <li>1. Make payment to the account above</li>
                  <li>2. Upload payment receipt for verification</li>
                  <li>3. Data delivered within 5 minutes after confirmation</li>
                </ol>
              </div>
              <Badge variant="secondary" className="text-sm">
                🛡️ SSL Encrypted • Anti-Fraud Protection • 24/7 Monitoring
              </Badge>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Available Networks */}
      <section className="py-16">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12">Available Networks</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {networks.map((network) => (
              <Card key={network.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="text-center">
                  <div
                    className={`w-16 h-16 ${network.color} rounded-full mx-auto mb-4 flex items-center justify-center`}
                  >
                    <span className="text-white font-bold text-xl">{network.name[0]}</span>
                  </div>
                  <CardTitle>{network.name}</CardTitle>
                  <CardDescription>{network.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {network.plans.slice(0, 2).map((plan, index) => (
                      <div key={index} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                        <span className="font-medium">{plan.size}</span>
                        <div className="text-right">
                          <span className="font-bold text-green-600">₦{plan.price}</span>
                          <div className="text-xs text-gray-500 line-through">₦{plan.originalPrice}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Link href={`/plans/${network.id}`}>
                    <Button className="w-full mt-4" variant="outline">
                      View All Plans
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12">Why Choose RealDynamic DataPlans?</h3>
          <p className="text-center text-gray-600 max-w-3xl mx-auto">
            We provide the most reliable and affordable data plans across all major networks in Nigeria. Our automated
            system ensures instant delivery and seamless transactions.
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Smartphone className="h-6 w-6" />
            <span className="text-xl font-bold">RealDynamic DataPlans</span>
          </div>
          <p className="text-gray-400">© 2024 RealDynamic DataPlans. All rights reserved.</p>
        </div>
      </footer>
    </div>
  )
}
