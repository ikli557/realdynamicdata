"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  amount: number
  planDetails: {
    network: string
    size: string
    phoneNumber: string
  }
}

export function PaymentModal({ isOpen, onClose, amount, planDetails }: PaymentModalProps) {
  const [paymentMethod, setPaymentMethod] = useState<"paystack" | "flutterwave" | "manual">("manual")

  const handlePaystackPayment = () => {
    // Initialize Paystack payment
    const handler = (window as any).PaystackPop.setup({
      key: process.env.NEXT_PUBLIC_PAYSTACK_PUBLIC_KEY,
      email: "customer@email.com",
      amount: amount * 100, // Convert to kobo
      currency: "NGN",
      callback: (response: any) => {
        // Verify payment and deliver data
        verifyAndDeliverData(response.reference, "paystack")
      },
      onClose: () => {
        console.log("Payment cancelled")
      },
    })
    handler.openIframe()
  }

  const handleFlutterwavePayment = () => {
    // Initialize Flutterwave payment
    const flw = (window as any).FlutterwaveCheckout({
      public_key: process.env.NEXT_PUBLIC_FLUTTERWAVE_PUBLIC_KEY,
      tx_ref: `RDD_${Date.now()}`,
      amount: amount,
      currency: "NGN",
      payment_options: "card,banktransfer,ussd",
      customer: {
        email: "customer@email.com",
        phone_number: planDetails.phoneNumber,
      },
      callback: (data: any) => {
        verifyAndDeliverData(data.transaction_id, "flutterwave")
      },
      onclose: () => {
        console.log("Payment cancelled")
      },
    })
  }

  const verifyAndDeliverData = async (reference: string, provider: string) => {
    try {
      const response = await fetch("/api/verify-payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reference, provider }),
      })

      const result = await response.json()

      if (result.success) {
        // Deliver data
        await fetch("/api/purchase-data", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            network: planDetails.network,
            planId: `${planDetails.network}_${planDetails.size.toLowerCase()}`,
            phoneNumber: planDetails.phoneNumber,
            paymentVerified: true,
          }),
        })

        alert("Payment successful! Data delivered.")
        onClose()
      } else {
        alert("Payment verification failed")
      }
    } catch (error) {
      alert("Error processing payment")
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Choose Payment Method</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold">Order Summary</h3>
            <p>
              {planDetails.network} - {planDetails.size}
            </p>
            <p>Phone: {planDetails.phoneNumber}</p>
            <p className="font-bold text-green-600">Amount: ₦{amount}</p>
          </div>

          <div className="space-y-3">
            <Button onClick={handlePaystackPayment} className="w-full bg-blue-600 hover:bg-blue-700">
              Pay with Paystack (Card/Bank)
            </Button>

            <Button onClick={handleFlutterwavePayment} className="w-full bg-orange-600 hover:bg-orange-700">
              Pay with Flutterwave (Card/USSD)
            </Button>

            <Button onClick={() => setPaymentMethod("manual")} variant="outline" className="w-full">
              Manual Bank Transfer
            </Button>
          </div>

          {paymentMethod === "manual" && (
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold">Bank Transfer Details</h4>
              <p>
                <strong>Account:</strong> 9153897727
              </p>
              <p>
                <strong>Bank:</strong> Opay
              </p>
              <p>
                <strong>Name:</strong> Adebayo Samuel Temitope
              </p>
              <p className="text-sm text-gray-600 mt-2">Send ₦{amount} and upload receipt for verification</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
