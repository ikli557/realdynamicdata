import type { NextRequest } from "next/server"

// In-memory store for rate limiting (use Redis in production)
const requestCounts = new Map<string, { count: number; resetTime: number }>()

// Clean up old entries every 10 minutes
setInterval(
  () => {
    const now = Date.now()
    for (const [key, value] of requestCounts.entries()) {
      if (now > value.resetTime) {
        requestCounts.delete(key)
      }
    }
  },
  10 * 60 * 1000,
)

export async function rateLimit(
  request: NextRequest,
  limit = 5,
  windowMs: number = 60 * 1000, // 1 minute
): Promise<{ success: boolean; remaining: number }> {
  const ip = request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "unknown"

  const now = Date.now()
  const windowStart = now - windowMs

  const key = `rate_limit:${ip}`
  const current = requestCounts.get(key)

  if (!current || now > current.resetTime) {
    // First request or window expired
    requestCounts.set(key, { count: 1, resetTime: now + windowMs })
    return { success: true, remaining: limit - 1 }
  }

  if (current.count >= limit) {
    // Rate limit exceeded
    return { success: false, remaining: 0 }
  }

  // Increment count
  current.count++
  return { success: true, remaining: limit - current.count }
}
