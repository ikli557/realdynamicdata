import crypto from "crypto"

// Input validation schemas
const validationRules = {
  network: /^(mtn|airtel|glo|9mobile)$/,
  planId: /^(mtn|airtel|glo|9mobile)_(500mb|1gb|2gb|3gb|5gb|10gb|15gb|20gb)$/,
  phoneNumber: /^(\+234|234|0)?[789][01]\d{8}$/,
  email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
}

export function validateInput(data: Record<string, any>): { isValid: boolean; errors: string[] } {
  const errors: string[] = []

  // Check for required fields
  const requiredFields = ["network", "planId", "phoneNumber"]
  for (const field of requiredFields) {
    if (!data[field]) {
      errors.push(`${field} is required`)
    }
  }

  // Validate network
  if (data.network && !validationRules.network.test(data.network)) {
    errors.push("Invalid network selected")
  }

  // Validate plan ID
  if (data.planId && !validationRules.planId.test(data.planId)) {
    errors.push("Invalid plan selected")
  }

  // Validate phone number
  if (data.phoneNumber && !validationRules.phoneNumber.test(data.phoneNumber)) {
    errors.push("Invalid phone number format")
  }

  // Validate email if provided
  if (data.email && !validationRules.email.test(data.email)) {
    errors.push("Invalid email format")
  }

  // Check for potential XSS attempts
  const xssPatterns = [/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, /javascript:/gi, /on\w+\s*=/gi]

  for (const [key, value] of Object.entries(data)) {
    if (typeof value === "string") {
      for (const pattern of xssPatterns) {
        if (pattern.test(value)) {
          errors.push(`Potentially malicious content detected in ${key}`)
        }
      }
    }
  }

  // Check for SQL injection patterns
  const sqlPatterns = [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXEC|UNION)\b)/gi,
    /('|(\\')|(;)|(--)|(\|)|(\*)|(%)|(\+))/g,
  ]

  for (const [key, value] of Object.entries(data)) {
    if (typeof value === "string") {
      for (const pattern of sqlPatterns) {
        if (pattern.test(value)) {
          errors.push(`Potentially malicious SQL content detected in ${key}`)
        }
      }
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
  }
}

export function sanitizeInput(input: string): string {
  return input
    .replace(/[<>]/g, "") // Remove angle brackets
    .replace(/javascript:/gi, "") // Remove javascript: protocol
    .replace(/on\w+\s*=/gi, "") // Remove event handlers
    .trim()
}

export function generateSecureHash(data: string, secret: string): string {
  return crypto.createHmac("sha256", secret).update(data).digest("hex")
}

export function verifySecureHash(data: string, hash: string, secret: string): boolean {
  const expectedHash = generateSecureHash(data, secret)
  return crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(expectedHash))
}

// Generate secure random tokens
export function generateSecureToken(length = 32): string {
  return crypto.randomBytes(length).toString("hex")
}

// Encrypt sensitive data
export function encryptData(data: string, key: string): string {
  const iv = crypto.randomBytes(16)
  const cipher = crypto.createCipher("aes-256-cbc", key)
  let encrypted = cipher.update(data, "utf8", "hex")
  encrypted += cipher.final("hex")
  return iv.toString("hex") + ":" + encrypted
}

// Decrypt sensitive data
export function decryptData(encryptedData: string, key: string): string {
  const parts = encryptedData.split(":")
  const iv = Buffer.from(parts[0], "hex")
  const encrypted = parts[1]
  const decipher = crypto.createDecipher("aes-256-cbc", key)
  let decrypted = decipher.update(encrypted, "hex", "utf8")
  decrypted += decipher.final("utf8")
  return decrypted
}
